
package antunez.recuperatorio1.pkg122;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;


public class Main {
    public static void main(String[] args) {
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        GestorEspectaculos gestor = new GestorEspectaculos();

        try {
            // Crear un concierto
            
            Concierto concierto = new Concierto(
                "Noche de Rock",
                LocalDate.of(2025, 10, 20),
                120,
                GeneroMusical.ROCK, 
                new ArrayList<String>(Arrays.asList("Banda 1", "Banda 2"))
            );
            

            // Crear una obra teatral
            ObraTeatral obra = new ObraTeatral(
                "María Pérez",
                Clasificacion.ATP,
                "La Comedia",
                LocalDate.of(2025, 10, 21),
                90
            );

            // Crear un festival
            Festival festival = new Festival(
                "Festival Primavera",
                LocalDate.of(2025, 10, 22),
                180,
                2,
                true
            );
            
            // Crear valido
            Concierto concierto1 = new Concierto(
                "Noche de Rock",
                LocalDate.of(2025, 10, 20),
                120,
                GeneroMusical.ROCK,
                new ArrayList<>(Arrays.asList("Banda 1", "Banda 2"))
            );
            

            // EXCP
            Concierto duplicado = new Concierto(
                "Noche de Rock",  // mismo nombre
                LocalDate.of(2025, 10, 20),  // misma fecha
                90,
                GeneroMusical.ROCK,
                new ArrayList<>(Arrays.asList("Otra Banda"))
            );
            
            
            

            // Agregarlos al gestor
            gestor.agregarEspectaculo(concierto);
            gestor.agregarEspectaculo(obra);
            gestor.agregarEspectaculo(festival);
            gestor.agregarEspectaculo(concierto1);
            gestor.agregarEspectaculo(duplicado); 

        } catch (EspectaculoDuplicadoException e) {
            System.out.println("❌ Error al agregar espectáculo: " + e.getMessage());
        }

        // Mostrar espectáculos
        System.out.println("\n📋 Espectáculos registrados:");
        gestor.mostrarEspectaculos();

        // Transmitir eventos
        System.out.println("\n📡 Transmitiendo eventos:");
        gestor.transmitirEventos();

        // Calificar eventos
        System.out.println("\n⭐ Calificando:");
        gestor.calificarEvento("Noche de Rock", 5);  // válido
        gestor.calificarEvento("Festival Primavera", 4);  // no calificable

        // Filtrar por género
        System.out.println("\n🎵 Filtrar por género ROCK:");
        gestor.filtrarPorGenero(GeneroMusical.ROCK);
    }
}
