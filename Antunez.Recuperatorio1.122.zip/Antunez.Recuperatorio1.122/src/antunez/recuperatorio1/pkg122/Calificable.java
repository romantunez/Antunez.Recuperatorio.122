package antunez.recuperatorio1.pkg122;

public interface Calificable {
    void calificar(int puntaje);
}
