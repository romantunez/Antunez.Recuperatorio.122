package antunez.recuperatorio1.pkg122;
import java.time.LocalDate;
import java.util.ArrayList;

public class Concierto extends Espectaculo implements Transmitible, Calificable {
    private GeneroMusical genero;
    private ArrayList<String> artistas;


    public Concierto(String nombre, LocalDate fecha, int duracion, GeneroMusical genero, ArrayList<String> artistas) {
        super(nombre, fecha, duracion);
        this.genero = genero;
        this.artistas = artistas;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo concierto: " + nombre);
    }

    @Override
    public void mostrar() {
        System.out.println("Concierto: " + nombre + " - Género: " + genero + " - Artistas: " + artistas);
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println(puntaje);
    }
}
    
