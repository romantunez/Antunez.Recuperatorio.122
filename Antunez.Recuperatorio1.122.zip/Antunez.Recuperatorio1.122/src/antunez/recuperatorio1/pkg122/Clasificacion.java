
package antunez.recuperatorio1.pkg122;


public enum Clasificacion {
    ATP,
    MAYOR13,
    MAYOR18
       
}
