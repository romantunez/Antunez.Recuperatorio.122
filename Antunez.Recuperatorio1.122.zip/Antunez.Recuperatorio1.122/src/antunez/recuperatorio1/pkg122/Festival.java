
package antunez.recuperatorio1.pkg122;
import java.time.LocalDate;


public class Festival extends Espectaculo implements Transmitible {
    
    private int escenarios;
    private boolean tieneCamping;

    public Festival(String nombre, LocalDate fecha, int duracion, int escenarios, boolean tieneCamping) {
        super(nombre, fecha, duracion);
        this.escenarios = escenarios;
        this.tieneCamping = tieneCamping;
    }

    @Override
    public void transmitir() {
        System.out.println("Transmitiendo festival en vivo: " + nombre);
    }

    @Override
    public void mostrar() {
        System.out.println("Festival: " + nombre + " - Escenarios: " + escenarios + " - Camping: " + tieneCamping);
    }
}

