package antunez.recuperatorio1.pkg122;

import java.time.LocalDate;

public class ObraTeatral extends Espectaculo implements Calificable {
    private String director;
    private Clasificacion clasificacionEdad;

    public ObraTeatral(String director, Clasificacion clasificacionEdad, String nombre, LocalDate fecha, int duracion) {
        super(nombre, fecha, duracion);
        this.director = director;
        this.clasificacionEdad = clasificacionEdad;
    }

    @Override
    public void mostrar() {
        System.out.println("Obra: " + nombre + " - Director: " + director);
    }

    @Override
    public void calificar(int puntaje) {
        System.out.println(puntaje);
    }
}
