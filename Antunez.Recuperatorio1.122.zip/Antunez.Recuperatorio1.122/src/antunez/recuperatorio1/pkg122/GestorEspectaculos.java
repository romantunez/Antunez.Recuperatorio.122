package antunez.recuperatorio1.pkg122;
import java.util.ArrayList;

public class GestorEspectaculos {
    
    private ArrayList<Espectaculo> espectaculo;

    public GestorEspectaculos() {
        this.espectaculo = new ArrayList<>();
    }

    public void agregarEspectaculo(Espectaculo e) throws EspectaculoDuplicadoException {
        for (Espectaculo otro : espectaculo) {
            if (otro.getNombre().equalsIgnoreCase(e.getNombre()) && otro.getFecha().equals(e.getFecha())) {
                throw new EspectaculoDuplicadoException("Ya existe un espectáculo con ese nombre y fecha.");
            }
        }
        espectaculo.add(e);
    }

    public void mostrarEspectaculos() {
        for (Espectaculo e : espectaculo) {
            System.out.println(e.toString());
        }
    }

    public void transmitirEventos() {
        for (Espectaculo e : espectaculo) {
            if (e instanceof Transmitible transmitible) {
                transmitible.transmitir();
            } else {
                System.out.println("El espectáculo \"" + e.getNombre() + "\" no puede ser transmitido.");
            }
        }
    }

    public ArrayList<Concierto> filtrarPorGenero(GeneroMusical g) {
        ArrayList<Concierto> resultado = new ArrayList<>();
        for (Espectaculo e : espectaculo) {
            if (e instanceof Concierto c) {
                if (c.getGenero() == g) {
                    resultado.add(c);
                    System.out.println(c.toString());
                }
            }
        }
        return resultado;
    }

    public void calificarEvento(String nombre, int puntaje) {
        for (Espectaculo e : espectaculo) {
            if (e.getNombre().equalsIgnoreCase(nombre)) {
                if (e instanceof Calificable calificable) {
                    calificable.calificar(puntaje);
                    return;
                } else {
                    System.out.println("El espectáculo \"" + nombre + "\" no se puede calificar.");
                    return;
                }
            }
        }
        System.out.println("No se encontró ningún espectáculo con ese nombre.");
    }
}

 

