
package antunez.recuperatorio1.pkg122;


public class EspectaculoDuplicadoException extends Exception {
    
      public EspectaculoDuplicadoException(String mensaje) {
      super(mensaje);
    }
}
