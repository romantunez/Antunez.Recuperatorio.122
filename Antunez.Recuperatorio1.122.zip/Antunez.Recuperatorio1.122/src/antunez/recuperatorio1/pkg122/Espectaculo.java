
package antunez.recuperatorio1.pkg122;
import java.time.LocalDate;

public abstract class Espectaculo {
    protected String nombre;
    protected LocalDate fecha;
    protected int duracion;

    public Espectaculo(String nombre, LocalDate fecha, int duracion) {
        this.nombre = nombre;
        this.fecha = fecha;
        this.duracion = duracion;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Espectaculo{" + "nombre=" + nombre + ", fecha=" + fecha + ", duracion=" + duracion + '}';
    }
    
    

    public abstract void mostrar();
}
  
