
package antunez.recuperatorio1.pkg122;


public enum GeneroMusical {
    POP,
    ROCK,
    JAZZ
    
}
