
package antunez.recuperatorio1.pkg122;

public interface Transmitible {
    void transmitir();
}
